#include <set>

class SetLib {
  public:

  bool add(int item, bool r) {
    //complete
    return true;
  }
	
  bool rmv(int item, bool r) {
    //complete
    return true;
  }
	
  bool ctn(int item, bool r) {
    //complete
    return true;
  }
		
  //Add your own member functions if needed

  private:
  std::set<int> state;
};
